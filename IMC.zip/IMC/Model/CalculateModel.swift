//
//  CalculateModel.swift
//  IMC
//
//  Created by Rayra Jovaneli on 5/19/22.
//

import UIKit

class calculateModel{
    
    var imc: Double = 0.0
    var image = ""

}
