//
//  ViewController.swift
//  IMC
//
//  Created by Rayra Jovaneli on 5/18/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

